Follow the slides
Change MATLAB path in scripts/setup.tcl to your MATLAB install folder. 

Choose one of the following options
 1) Run runme.m. 
    - This script will launch Vivado in batch mode, generate Bitfile and program the FPGA.
    - Bypass Step 5 to 8, Go to step 11 for debugging using Data Capture App. 
2) Run program_soln.m 
   - This script programs FPGA with existing Bit file in solution  folder.
   - Go to step 11 for debugging using Data Capture App 
3) Following all steps for Demo2 listed in slides. 