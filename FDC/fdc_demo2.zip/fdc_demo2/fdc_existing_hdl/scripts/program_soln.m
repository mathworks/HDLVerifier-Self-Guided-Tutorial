%# Program FPGA
system('vivado -mode batch -source ./scripts/program_soln.tcl &')

